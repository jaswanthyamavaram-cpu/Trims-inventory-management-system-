## Packages
recharts | Dashboard charts and visualization
framer-motion | Smooth transitions and industrial interface animations
date-fns | Date formatting for logs

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Rajdhani'", "sans-serif"],
  mono: ["'JetBrains Mono'", "monospace"],
  body: ["'Inter'", "sans-serif"],
}
